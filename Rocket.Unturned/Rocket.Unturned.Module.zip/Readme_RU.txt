RocketModFix для Unturned
-------------------------

https://github.com/RocketModFix/RocketModFix
Самую новейшую версию можно найти здесь: https://github.com/RocketModFix/RocketModFix/releases.

Установка
---------

Скопируйте "Rocket.Unturned" папку в /Unturned/Modules (скопируйте всю папку а не то что в находится внутри папки и если оно просит вставить с заменой то жмите вставить с заменой).

Дополнительная информация по установке: https://github.com/RocketModFix/RocketModFix?tab=readme-ov-file#installation