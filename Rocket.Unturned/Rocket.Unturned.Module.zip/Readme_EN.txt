RocketModFix for Unturned
-------------------------

https://github.com/RocketModFix/RocketModFix
For latest downloads, visit: https://github.com/RocketModFix/RocketModFix/releases.

Installation
------------

Copy the "Rocket.Unturned" folder to /Unturned/Modules (copy the folder, not it's content, and if its asks to Replace the existing files then press to replace them).

For more, visit: https://github.com/RocketModFix/RocketModFix?tab=readme-ov-file#installation